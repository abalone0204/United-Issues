$(function(){
  $('.dropdown-toggle').dropdownHover();
});
